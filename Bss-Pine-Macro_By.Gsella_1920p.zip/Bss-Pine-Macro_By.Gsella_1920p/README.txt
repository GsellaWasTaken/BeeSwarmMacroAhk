For 1920 1080p
v.1.3.1e

Changes::

-Option to use 3 planters
-Option to choose sprinkler count
-General improvements
-New Walk to convert path