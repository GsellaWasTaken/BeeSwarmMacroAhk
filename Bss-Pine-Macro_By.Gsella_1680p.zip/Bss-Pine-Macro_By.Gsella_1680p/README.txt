For 1680 1050p
v.1.3.2e

Changes::

-Option to use 3 planters
-Option to choose sprinkler count
-General improvements
-New Walk to convert path
